CREATED BY: LUCAS GOMES PALMIERI
http://www.lucasgomespalmieri.com.br/

OBS:
- Move with W,A,S,D
- Shift to run
- Interact with F
- Interactable objects or NPC's will show a indication when near enough
- Empty buckets normally contains infinite free coins